# TreeProfiler commands and related arguments naming review

This is the review of all existing treeprofiler commands and arguments naming in order to increase users experience before release. 

I will show all the arguments and commands (annotate, plot) individually first with the exact usage including expected input and output.  

# Index

1. **Source Tree Arguments** [**`Source Tree Arguments`** ](https://www.notion.so/Source-Tree-Arguments-4261da1bda78440ca27cb252a97fc08b?pvs=21) 
2. **Annotation Arguments** [`annotate` ](https://www.notion.so/annotate-9d9aa8ed8e0d45989ce6266c27eb2fb9?pvs=21) 
3. **Plot Arguments** [`plot` ](https://www.notion.so/plot-05679cc4b5e140158e47aec8d893c471?pvs=21) 

# Enviroment installation and examples
https://github.com/dengzq1234/treeprofiler_demo

# **`Source Tree Arguments`**

The following arguments are shared in both `annotate` and `plot` 

| Argument | Description | Comments |
| --- | --- | --- |
| -t TREE, --tree TREE | Input tree, .nw file, customized tree input. |  |
| --internal-parser {name,support} | Specify how to interpret internal nodes in newick format. [default: support] |  |
| --input-type {auto,newick,ete} | Treeprofiler can detect tree type automatically unless uses want to specify input tree format. [newick, ete]. [default: auto] |  |
| --resolve-polytomy | Resolve polytomy in tree. |  |

**Tree format**

TreeProfiler support and automatically detect the input tree in the following formats:

- newick
- ete

Explain tree format with basic usage

```bash
cd 00_tree/
ls
demo1.ete  demo1.nw  demo1.tsv  internal_name.tree  internal_support.tree

# test tree arguments with plot sub command, visualize naked tree

# visualize naked ete or newick tree
treeprofiler plot -t demo1.ete --input-type ete

treeprofiler plot -t demo1.nw --input-type newick

# or defaultly let program detect
treeprofiler plot -t demo1.ete 
```

**Tree Parser**

| newick | leaves | internal_node value | internal_parser |
| --- | --- | --- | --- |
| (A:0.5, B:0.5)Internal_C:0.5; | A, B | Internal_C | name |
| (A:0.5, B:0.5)0.99:0.5; | A, B | 0.99 | support [default] |

***ete tree format is not effected by internal parser*ete tree format is not effected by internal parser**

explain tree parser with basic usage

```bash
cd 00_tree/
ls
demo1.ete  demo1.nw  demo1.tsv  internal_name.tree  internal_support.tree

# visualize newick tree with internal name
treeprofiler plot -t internal_name.tree --internal-parser name

# visualize newick tree with support
treeprofiler plot -t internal_support.tree --internal-parser support
# or just
treeprofiler plot -t internal_support.tree
```

# `annotate`

Annotate subcommand is about how users want to map the metadata to taget tree.

## Quick Start

```bash
cd 01_annotate/

treeprofiler annotate -t demo1.tree \
--metadata categorical.tsv boolean.tsv numerical.tsv \ 
-sep , \
-o ./

# just to show some examples
treeprofiler plot -t demo1_annotated.ete \
--rectangle-layout categorical1 \
--heatmap-layout random_column1 random_column2 random_column3 \
--binary-layout boolean_column integer_column  \
--column-width 50
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled.png)

## Arguments for Metadata tsv/csv file

METADATA TABLE parameters:Input parameters of METADATA

| Argument | Description | Super link to examples | Note | Comments |
| --- | --- | --- | --- | --- |
| -d METADATA [METADATA ...], --metadata METADATA [METADATA ...] | <metadata.csv> .csv, .tsv filename | Basic metadata tsv/csv file (https://www.notion.so/Basic-metadata-tsv-csv-file-05b38f377bd446bb8281404d81c4a847?pvs=21)  |  |  |
| -sep METADATA_SEP, --metadata-sep METADATA_SEP | column separator of metadata table [default: \t] | Basic metadata tsv/csv file (https://www.notion.so/Basic-metadata-tsv-csv-file-05b38f377bd446bb8281404d81c4a847?pvs=21)  |  |  |
| --no-headers  | metadata table doesn't contain columns name, namespace col+index will be assigned as the key of property such as col1. | Metadata tsv/csv file without column names (https://www.notion.so/Metadata-tsv-csv-file-without-column-names-856868870c204a9791cad15becef6cf1?pvs=21)  |  |  |
| --data-matrix DATA_MATRIX [DATA_MATRIX ...] | <datamatrix.csv> .csv, .tsv. numerical matrix data metadata table as array to tree, please do not provide column headers in this file, filename will become the property name in the tree. | Metadata tsv/csv file as a numerical data matrix (https://www.notion.so/Metadata-tsv-csv-file-as-a-numerical-data-matrix-e256df6c92894f2ba7e10922ebc8b8b3?pvs=21)  |  |  |
| --duplicate | treeprofiler will aggregate duplicated metadata to a list as a property if metadata contains duplicated row | Metadata tsv/csv file with duplicated leaf names (https://www.notion.so/Metadata-tsv-csv-file-with-duplicated-leaf-names-b970248d77a449aea067b0851e1505c1?pvs=21)  |  |  |

### Basic metadata tsv/csv file

TreeProfiler allows users to input metadata in tsv/csv file by setting **`-**-metadata <filename.tsv|.csv>`  ****and ****`-sep <seperator>` . By default, the first column of metadata should be names of target tree leaves and metadata should contain column names for each column of metadata.

example:

```bash
# check metadata structure
head categorical.tsv
name,categorical1
Taxa_0,A
Taxa_1,B
Taxa_2,B
Taxa_3,C

# set the correct filename and seperator
treeprofiler annotate \
-t demo1.tree \
--metadata categorical.tsv \
-sep , \
-o .

# show tree's properties
python show_tree_props.py demo1_annotated.nw

Target tree internal node Root contains the following properties:  
{'categorical1_counter': 'A--1||B--2||C--2', 'name': 'Root'}
Target tree leaf node Taxa_0 contains the following propertiies:  
{'name': 'Taxa_0', 'dist': 0.190563, 'categorical1': 'A'}

                                           ╭╴Taxa_4,C,⊗
                         ╭╴N2,⊗,A--1||C--1╶┤
                         │                 ╰╴Taxa_0,A,⊗
╴Root,⊗,A--1||B--2||C--2╶┤
                         │                             ╭╴Taxa_2,B,⊗
                         │                 ╭╴N5,⊗,B--2╶┤
                         ╰╴N7,⊗,B--2||C--1╶┤           ╰╴Taxa_1,B,⊗
                                           │
                                           ╰╴Taxa_3,C,⊗
```

### Metadata tsv/csv file without column names

If metadata doesn’t have headers, by setting **`--no-headers`** to set the metadata properly, therefore treeprofiler will name each column by `col`+`<column number>` as the property key in each leaf node, such as `col1`, `col2`, etc.

example:

```bash
# data.array doesn't have headers for each column 
head data.array
Taxa_0,-2.591,1.937,-3.898,0.447,-1.349
Taxa_1,3.366,-1.871,4.362,1.585,-2.479
Taxa_2,0,-0.098,0,-3.326,2.746
Taxa_3,3.671,-0.947,-4.509,-3.131,-2.194

# need to add --no-headers flag to tell treeprofiler
treeprofiler annotate \
-t demo1.tree \
--metadata data.array \
-sep , \
--no-headers \
-o .

# check properties
python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{'col1_avg': '1.92825', 
'col1_max': '3.671', 
'col1_min': '0.0', 
'col1_std': '3.463526916666666', 
'col1_sum': '7.713', 
'col2_avg': '-1.318', 
...}

target tree leaf node Taxa_0 contains the following propertiies:  
{'name': 'Taxa_0', 
'dist': 0.190563, 
'col1': '-2.591', 
'col2': '1.937', 
'col3': '-3.898', 
'col4': '0.447', 
'col5': '-1.349'}
```

### Metadata tsv/csv file as a numerical data matrix

treeprofiler can handle the whole tsv/csv file as one property and annotate it to related leaf, by using `--data-matrix <filename.tsv|.csv>` It must be numerical data matrix and without headers. Once annotated the property of data-matrix will be named by the filename (see example below) 

The different between `--data-matrix` and `--metadata` is the former see the whole metadata file as a node property and store the rows as a array in leaf node, and the latter see each column from metadata as each single property of leaf node. 

Using data array file `data.array` from the previous example

```bash
# annotated data.array file to tree
treeprofiler annotate \
-t demo1.tree \
--data-matrix data.array \
-sep , \
-o .

# data.array is stored as one property in tree node and value is stored as array
python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{
'data.array_avg': '1.0244|-0.667|-1.7740000000000002|-0.8620000000000001|-0.6552', 
'data.array_max': '3.671|1.937|4.362|1.585|2.746', 
'data.array_min': '-2.591|-2.356|-4.825|-3.326|-2.479', 
'data.array_std': '2.3121192529798287|1.5156064132880938|3.524138873540599|1.9937640783202009|1.906460531980665', 
'data.array_sum': '5.122|-3.335|-8.870000000000001|-4.3100000000000005|-3.276', 
'name': 'Root'
}
target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'Taxa_0', 
'dist': 0.190563, 
'data.array': '-2.591|1.937|-3.898|0.447|-1.349'
}
```

### Metadata tsv/csv file with duplicated leaf names

In general, treeprofiler expects each row of metadata corresponding to one leaf, such as 

```bash
head categorical.tsv
#name,categorical1
Taxa_0,A
Taxa_1,B
Taxa_2,B
Taxa_3,C
Taxa_4,C
```

Although treeprofiler can handle metadata with rows with duplicated leafnames such as

```bash
head categorical_duplicated.tsv
#name,categorical1
Taxa_0,A
Taxa_0,B
Taxa_2,B
Taxa_2,C
Taxa_3,C
Taxa_3,A
Taxa_4,C
```

In order to do so, users need to add **`--duplicate`** , by doing so, metadata from the same leaf will be aggregate into the same column. Such as the Taxa_0 from the above table, at the end value `A` and `B` will be both annotated to property `categorical1`(see above demo)**. If not, treeprofielr will take one the first row of metadata that appear as the metadata for related leaf!**

example

```bash
treeprofiler annotate \
-t demo1.tree \
-d categorical_duplicated.tsv \
-sep , \
--duplicate \
-o .

python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{'categorical1_counter': 'A--2||B--2||C--3', 'name': 'Root'}
target tree leaf node Taxa_0 contains the following propertiies:  
{'name': 'Taxa_0', 'dist': 0.190563, 'categorical1': 'A|B'}
```

## Arguments for datatype of columns from metadata (not necessary)

In general treeprofiler can detect datatype of each column so the following arguments are not necessary to used unless treeprofile made mistakes so users can use the following arguments to correct the data type of certain columns by adding columns’ headers or index.

| Argument | Description | Range of values | Note | Comments |
| --- | --- | --- | --- | --- |
| --text-prop TEXT_PROP [TEXT_PROP ...] | <col1> <col2> names, column index or index range of columns which need to be read as categorical data | all | auto detect |  |
| --multiple-text-prop MULTIPLE_TEXT_PROP [MULTIPLE_TEXT_PROP ...] | <col1> <col2> names, column index or index range of columns which need to be read as categorical data which contains more than one value and separate by , such as GO:0000003,GO:0000902,GO:0000904,GO:0003006 | a,b,c; GO:0000002,GO:0000003; 
ko01522,ko01524 | auto detect |  |
| --num-prop NUM_PROP [NUM_PROP ...] | <col1> <col2> names, column index or index range of columns which need to be read as numerical data | 10; 0.1; 1e-6 | auto detect |  |
| --bool-prop BOOL_PROP [BOOL_PROP ...] | <col1> <col2> names, column index or index range of columns which need to be read as boolean data | True; False; yes; no; t; f; 1; 0;  | auto detect |  |
| --text-prop-idx TEXT_PROP_IDX [TEXT_PROP_IDX ...] | 1 2 3 or [1-5] index of columns which need to be read as categorical data |  | auto detect |  |
| --num-prop-idx NUM_PROP_IDX [NUM_PROP_IDX ...] | 1 2 3 or [1-5] index columns which need to be read as numerical data |  | auto detect |  |
| --bool-prop-idx BOOL_PROP_IDX [BOOL_PROP_IDX ...] | 1 2 3 or [1-5] index columns which need to be read as boolean data |  | auto detect |  |

## Arguments for summary method for different datatypes

| Argument | Appliced datatype | Description | Summarized properties Internal node | examples | Comments |
| --- | --- | --- | --- | --- | --- |
| --num-stat {all,sum,avg,max,min,std,none} | numerical data matrix  | Descriptive Statistic (average, sum, max, min, standard deviation) | <prop name>_avg
<feature name>_sum
<feature name>_max
<feature name>_min
<feature name>_std | Numerical (https://www.notion.so/Numerical-9b149898ffc44dcdb5d2dabe6c0294bb?pvs=21) |  |
| --counter-stat {raw,relative,none} | str 
boolean
list | Raw/Relative Counter | <feature name>_counter | Categorical (https://www.notion.so/Categorical-7dc500047abf41fb99c1f1c09355b52b?pvs=21)  |  |
| --num-stat {all,sum,avg,max,min,std,none} | float 
int | Descriptive Statistic (average, sum, max, min, standard deviation) | <feature name>_avg
<feature name>_sum
<feature name>_max
<feature name>_min
<feature name>_std | Numerical (https://www.notion.so/Numerical-9b149898ffc44dcdb5d2dabe6c0294bb?pvs=21)  |  |
| --column-summary-method COLUMN_SUMMARY_METHOD [COLUMN_SUMMARY_METHOD ...]
 | all | Specify summary method for individual columns in the format ColumnName=Method, such as
--column-summary-method sample1=none sample2=avg random_type=relative alignment=none |  | Customize different summary method based on different columns (https://www.notion.so/Customize-different-summary-method-based-on-different-columns-f9423477779a4eabbb084c98cfb1dd82?pvs=21)  |  |

### Choosing different summary method for categorical or numerical data

- **Categorical**

boolean and text properties (categorical data) of leaf nodes will be summarized as counter in internal ndoes, currently users can choose using `raw` (default), `relative` or `none` for counter. Users can use `--counter-stat {raw,relative,none}` to choose the counter, it will automatically apply to all categorical properties.

```bash
# raw counter (default)
treeprofiler annotate \
-t demo1.tree \
--metadata categorical.tsv \
-sep , \
--counter-stat raw \
-o ./ 

python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{
'categorical1_counter': 'A--1||B--2||C--2', 
'name': 'Root'
}
target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'Taxa_0', 
'dist': 0.190563, 
'categorical1': 'A'
}

#relative counter to calculate the percentage
treeprofiler annotate \
-t demo1.tree \
--metadata categorical.tsv \
-sep , \
--counter-stat relative \
-o ./

python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{
'categorical1_counter': 'A--0.20||B--0.40||C--0.40', 
'name': 'Root'
}
target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'Taxa_0', 
'dist': 0.190563, 
'categorical1': 'A'
}

#set to none
treeprofiler annotate \
-t demo1.tree \
--metadata categorical.tsv \
-sep , \
--counter-stat none \
-o ./

python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{'name': 'Root'}
target tree leaf node Taxa_0 contains the following propertiies:  
{'name': 'Taxa_0', 'dist': 0.190563, 'categorical1': 'A'}
```

- **Numerical**

By default, numerical feature will be calculated all the descriptive statistic, but users can choose specific one to be calculated by using `--num-stat [all, sum, avg, max, min, std, none]`  . `all` (default) means it will conduct all the statistic. 

Noticed that `--num-stat` will also work on `--data-matrix` data. 

```bash
# conduct all statistic (by default)
treeprofiler annotate \
-t demo1.tree \
--metadata numerical.tsv \
-sep , \
--num-stat all \
-o ./

python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{
'name': 'Root', 
'random_column1_avg': '0.5384554640742852', 
'random_column1_max': '0.7817176831389784', 
'random_column1_min': '0.3276816717486982', 
'random_column1_std': '0.028430041000376213', 
'random_column1_sum': '2.692277320371426',
....
}
target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'Taxa_0', 
'dist': 0.190563, 
'random_column1': '0.45303222603186877', 
'random_column2': '1.9801547427961053', 
'random_column3': '43.0'}

# conduct only average 
treeprofiler annotate \
-t demo1.tree \
--metadata numerical.tsv \
-sep , \
--num-stat avg \
-o ./

python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{
'name': 'Root', 
'random_column1_avg': '0.5384554640742852', 
'random_column2_avg': '0.12655333321138568', 
'random_column3_avg': '52.2'
}

target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'Taxa_0', 
'dist': 0.190563, 
'random_column1': '0.45303222603186877', 
'random_column2': '1.9801547427961053', 
'random_column3': '43.0'}

# conduct none statistic
treeprofiler annotate \
-t demo1.tree \
--metadata numerical.tsv \
-sep , \
--num-stat none \
-o ./

python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{'name': 'Root'}
target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'Taxa_0', 
'dist': 0.190563, 
'random_column1': '0.45303222603186877', 
'random_column2': '1.9801547427961053', 
'random_column3': '43.0'
}

# data matrix is also effected by --num-stat setting

# only average 
treeprofiler annotate \
-t demo1.tree \
--data-matrix data.array \
-sep , \
--num-stat avg \
-o ./

python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{
'data.array_avg': '1.0244|-0.667|-1.7740000000000002|-0.8620000000000001|-0.6552', 
'name': 'Root'
}
target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'Taxa_0', 
'dist': 0.190563,  
'data.array': '-2.591|1.937|-3.898|0.447|-1.349'
}
```

### Customize different summary method based on different columns

Using `--column-summary-method`  can specify the summary method of each properties, simply add `<property name>=<summary method>` . For categorical data, options are `raw,relative,none`; for numerical data, options are  `all, sum, avg, max, min, std, none` . 

such as `--column-summary-method sample1=none sample2=avg random_type=relative alignment=none`

Noted that `--data-matrix` can be effected by `--column-summary-method` setting, in this case filename of the data matrix is property name, such as`--data-matrix file.tsv --column-summary-method file.tsv=avg`

example:

here we use three different metadata: categorical tsv, numerical tsv and data matrix

```bash
# cusomtize different summary methods for different column/property
treeprofiler annotate \
-t demo1.tree \
--metadata categorical.tsv numerical.tsv \
--data-matrix data.array \
-sep , \
--column-summary-method \
categorical1=relative \
random_column1=all \
random_column2=none \
random_column3=sum \
data.array=avg \
-o ./

python show_tree_props.py demo1_annotated.nw
target tree internal node Root contains the following properties:  
{
'name': 'Root', 
'categorical1_counter': 'A--0.20||B--0.40||C--0.40', 
'random_column1_avg': '0.5384554640742852', 
'random_column1_max': '0.7817176831389784', 
'random_column1_min': '0.3276816717486982', 
'random_column1_std': '0.028430041000376213', 
'random_column1_sum': '2.692277320371426', 
'random_column3_sum': '261.0',
'data.array_avg': '1.0244|-0.667|-1.7740000000000002|-0.8620000000000001|-0.6552'
}
target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'Taxa_0', 
'dist': 0.190563,  
'categorical1': 'A', 
'random_column1': '0.45303222603186877', 
'random_column2': '1.9801547427961053', 
'random_column3': '43.0',
'data.array': '-2.591|1.937|-3.898|0.447|-1.349'
}
```

## Arguments for Taxonomic Annotation

| Argument | Description | Examples | Notes |
| --- | --- | --- | --- |
| --taxadb {NCBI,GTDB,customdb} | choose NCBI or GTDB database | Taxnonomic annotation using different databases with different versions (https://www.notion.so/Taxnonomic-annotation-using-different-databases-with-different-versions-8f209fc9ccaa41e6b9574a84619d1812?pvs=21)  | customdb is not implemented yet  |
| --gtdb-version {95,202,207,214,220} | GTDB version for taxonomic annotation, such as 220. If it is not provided, the latest version will be used. | GTDB examples (https://www.notion.so/GTDB-examples-6c6c5cfe8b2848b6ba06842c905fd3f8?pvs=21)  |  |
| --taxa-dump TAXA_DUMP | Path to taxonomic database dump file for specific version, such as gtdb taxadump https://github.com/etetoolkit/ete-data/raw/main/gtdb_taxonomy/gtdblatest/gtdb_latest_dump.tar.gz or NCBI taxadump https://ftp.ncbi.nlm.nih.gov/pub/taxonomy/taxdump.tar.gz | NCBI examples (https://www.notion.so/NCBI-examples-d13445740e644ba1a252ff7da12e3c1b?pvs=21)  |  |
| --taxon-column TAXON_COLUMN | Activate taxonomic annotation using <col1> name of columns which need to be read as taxon data. Unless taxon data in leaf name, please use 'name' as input such as --taxon-column name | GTDB examples (https://www.notion.so/GTDB-examples-6c6c5cfe8b2848b6ba06842c905fd3f8?pvs=21)  |  |
| --taxon-delimiter TAXON_DELIMITER | delimiter of taxa columns. [default: None] | Taxnonomic annotation when taxon name in different position  (https://www.notion.so/Taxnonomic-annotation-when-taxon-name-in-different-position-ad685862bc044f86af2298a3edb33004?pvs=21)  |  |
| --taxa-field TAXA_FIELD | field of taxa name after delimiter. [default: 0] | Taxnonomic annotation when taxon name in different position  (https://www.notion.so/Taxnonomic-annotation-when-taxon-name-in-different-position-ad685862bc044f86af2298a3edb33004?pvs=21)  |  |
| --ignore-unclassified | Ignore unclassified taxa in taxonomic annotation | Ignore unclassified annotation (https://www.notion.so/Ignore-unclassified-annotation-444d59808c27437992d7293730bd504a?pvs=21)  |  |

### Taxnonomic annotation using different databases with different versions

To start taxonomic annotation, using `--taxon-column` and `--taxadb` to locate where is the taxon and which taxonomic databases to be used. If taxon is leaf name, then using `--taxon-column name` , otherwise `--taxon-column {prop_name}` which refers to the column in the metadata.

**NCBI examples**

```bash
# check example tree
cat ncbi.tree
((9606, 9598), 10090);

# run taxonomic annotation and locate taxon column in leaf name
treeprofiler annotate -t ncbi.tree --taxon-column name --taxadb ncbi -o .

# check annotation results
python show_tree_props.py ncbi_annotated.nw
Target tree internal node Root contains the following properties:  
{
'common_name': '', 
'evoltype': 'S', 
'lca': 'no rank-cellular organisms|superkingdom-Eukaryota|clade-Eumetazoa|phylum-Chordata|superclass-Sarcopterygii|kingdom-Metazoa|class-Mammalia|subphylum-Craniata|superorder-Euarchontoglires', 
'lineage': '1|131567|2759|33154|33208|6072|33213|33511|7711|89593|7742|7776|117570|117571|8287|1338369|32523|32524|40674|32525|9347|1437010|314146', 
'name': 'Root', 
'named_lineage': 'root|Eukaryota|Eumetazoa|Chordata|Vertebrata|Gnathostomata|Sarcopterygii|Eutheria|Tetrapoda|Amniota|Theria|Opisthokonta|Metazoa|Bilateria|Deuterostomia|Mammalia|Craniata|Teleostomi|Euteleostomi|cellular organisms|Euarchontoglires|Dipnotetrapodomorpha|Boreoeutheria', 'rank': 'superorder', 
'sci_name': 'Euarchontoglires', 
'species': '10090|9606|9598', 
'taxid': '314146'
}
Target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': '9606', 
'dist': 1.0, 
'common_name': 
'Homo sapiens', 
'lca': 'no rank-cellular organisms|superkingdom-Eukaryota|clade-Eumetazoa|phylum-Chordata|superclass-Sarcopterygii|order-Primates|parvorder-Catarrhini|family-Hominidae|genus-Homo|species-Homo sapiens|kingdom-Metazoa|class-Mammalia|subphylum-Craniata|subfamily-Homininae|superorder-Euarchontoglires|infraorder-Simiiformes|superfamily-Hominoidea|suborder-Haplorrhini', 
'lineage': '1|131567|2759|33154|33208|6072|33213|33511|7711|89593|7742|7776|117570|117571|8287|1338369|32523|32524|40674|32525|9347|1437010|314146|9443|376913|314293|9526|314295|9604|207598|9605|9606', 
'named_lineage': 'root|Eukaryota|Eumetazoa|Chordata|Vertebrata|Gnathostomata|Sarcopterygii|Eutheria|Primates|Catarrhini|Hominidae|Homo|Homo sapiens|Tetrapoda|Amniota|Theria|Opisthokonta|Metazoa|Bilateria|Deuterostomia|Mammalia|Craniata|Teleostomi|Euteleostomi|cellular organisms|Homininae|Euarchontoglires|Simiiformes|Hominoidea|Haplorrhini|Dipnotetrapodomorpha|Boreoeutheria', 
'rank': 'species', 
'sci_name': 'Homo sapiens', 
'species': '9606', 
'taxid': '9606'
}

# annotation with updated taxonomic database version 
treeprofiler annotate \
-t ncbi.tree \
--taxon-column name \
--taxadb ncbi \
--taxa-dump taxdump.tar.gz \
-o ./
```

**GTDB examples**

for gtdb taxa, users can choose `--gtdb-version {95,202,207,214,220}` to select certain version, if not, latest gtdb db will be used.

```bash
# check example tree
cat gtdb_v202.tree 
(GB_GCA_011358815.1:1,(RS_GCF_000019605.1:1,(RS_GCF_003948265.1:1,GB_GCA_003344655.1:1):0.5):0.5);

# default using latest version, in this case on tree from version 202, it should go empty
treeprofiler annotate \
-t gtdb_v202.tree \
--taxon-column name \
--taxadb gtdb \
-o ./

python show_tree_props.py gtdb_v202_annotated.nw
Target tree internal node Root contains the following properties:  
{
'common_name': '', 
'evoltype': 'S', 
'lca': '', 'lineage': '', 
'name': 'Root', 
'named_lineage': '', 
'rank': 'Unknown', 
'sci_name': 'None', 
'species': 'RS_GCF_000019605.1|RS_GCF_003948265.1|GB_GCA_011358815.1|GB_GCA_003344655.1', 
'taxid': 'None'
}
Target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'GB_GCA_011358815.1', 
'dist': 1.0, 
'common_name': '', 
'named_lineage': '', 
'rank': 'Unknown', 
'sci_name': '', 
'species': 'GB_GCA_011358815.1', 
'taxid': 'GB_GCA_011358815.1'
}

#annotate tree using the proper version of GTDB 
treeprofiler annotate \
-t gtdb_v202.tree \
--taxon-column name \
--taxadb gtdb \
--gtdb-version 202 \
-o ./

# now it's correctly annotated
python show_tree_props.py gtdb_v202_annotated.nw
Target tree internal node Root contains the following properties:  
{
'common_name': '', 
'evoltype': 'S', 
'lca': 'superkingdom-d__Archaea|phylum-p__Thermoproteota|class-c__Korarchaeia|order-o__Korarchaeales|family-f__Korarchaeaceae|genus-g__Korarchaeum', 
'lineage': '1|2|79|2172|2173|2174|2175', 'name': 'Root', 
'named_lineage': 'root|d__Archaea|p__Thermoproteota|c__Korarchaeia|o__Korarchaeales|f__Korarchaeaceae|g__Korarchaeum', 
'rank': 'genus', 'sci_name': 'g__Korarchaeum', 
'species': 'RS_GCF_003948265.1|GB_GCA_011358815.1|RS_GCF_000019605.1|GB_GCA_003344655.1', 
'taxid': 'g__Korarchaeum'
}
Target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'GB_GCA_011358815.1', 
'dist': 1.0, 
'common_name': '', 
'lca': 'superkingdom-d__Archaea|phylum-p__Thermoproteota|class-c__Korarchaeia|order-o__Korarchaeales|family-f__Korarchaeaceae|genus-g__Korarchaeum|species-s__Korarchaeum cryptofilum|subspecies-s__Korarchaeum cryptofilum', 
'named_lineage': 'root|d__Archaea|p__Thermoproteota|c__Korarchaeia|o__Korarchaeales|f__Korarchaeaceae|g__Korarchaeum|s__Korarchaeum cryptofilum|GB_GCA_011358815.1', 
'rank': 'subspecies', 
'sci_name': 's__Korarchaeum cryptofilum', 
'species': 'GB_GCA_011358815.1', 
'taxid': 'GB_GCA_011358815.1'
}
```

### Taxnonomic annotation when taxon name in different position

Sometimes taxon name can be in different positions, could be in leaf node name, differen columns, or with embedded in cell with other information seperated by different delimiters. using `--taxon-column TAXON_COLUMN` , `--taxon-delimiter TAXON_DELIMITER` and `--taxa-field TAXA_FIELD`

```bash
# check example tree and metadata
cat demo3.tree
(Taxa_2:0.471596,((Taxa_0:0.767844,Taxa_1:0.792161)0.313833:0.684109,Taxa_3:0.805286):0.188666);

cat demo3.tsv
#name	gtdb_taxid
Taxa_0	GB_GCA_011358815.1@sample1
Taxa_1	RS_GCF_000019605.1@sample2
Taxa_2	RS_GCF_003948265.1@sample3
Taxa_3	GB_GCA_003344655.1@sample4

# therefore, locate taxa id correctly
treeprofiler annotate \
-t demo3.tree \
-d demo3.tsv \
--taxon-column gtdb_taxid \
--taxadb gtdb \
--gtdb-version 202 \
--taxon-delimiter @ \
--taxa-field 0 \
-o ./

python show_tree_props.py demo3_annotated.nw
Target tree internal node Root contains the following properties:  
{
'common_name': '', 
'evoltype': 'S', 
'lca': 'superkingdom-d__Archaea|phylum-p__Thermoproteota|class-c__Korarchaeia|order-o__Korarchaeales|family-f__Korarchaeaceae|genus-g__Korarchaeum', 
'name': 'Root', 
'named_lineage': 'root|d__Archaea|p__Thermoproteota|c__Korarchaeia|o__Korarchaeales|f__Korarchaeaceae|g__Korarchaeum', 
'rank': 'genus', 
'sci_name': 'g__Korarchaeum', 
'species': 'Taxa_3|Taxa_0|Taxa_1|Taxa_2', 
'taxid': 'g__Korarchaeum'
}
Target tree leaf node contains the following propertiies:  
{
'name': 'Taxa_2', 
'dist': 0.471596, 
'common_name': '', 
'gtdb_taxid': 'RS_GCF_003948265.1', 
'lca': 'superkingdom-d__Archaea|phylum-p__Thermoproteota|class-c__Korarchaeia|order-o__Korarchaeales|family-f__Korarchaeaceae|genus-g__Korarchaeum|species-s__Korarchaeum cryptofilum|subspecies-s__Korarchaeum cryptofilum', 
'named_lineage': 'root|d__Archaea|p__Thermoproteota|c__Korarchaeia|o__Korarchaeales|f__Korarchaeaceae|g__Korarchaeum|s__Korarchaeum cryptofilum|RS_GCF_003948265.1', 
'rank': 'subspecies', 
'sci_name': 's__Korarchaeum cryptofilum', 
'species': 'Taxa_2', 
'taxid': 'RS_GCF_003948265.1'
}
```

### Ignore unclassified annotation

Taxonomic annotation will annotate the internal nodes based on the taxa of leaf nodes, but if leaf node has unknown taxonomic information, the internal nodes will return unknown annotation. Using 

`--ignore-unclassified` to ignore the unknown annotation from leaves 

```bash
# check tree with unknown taxa
(Taxa_1:1,(RS_GCF_000019605.1:1,(Taxa_2:1,GB_GCA_003344655.1:1):0.5):0.5);

# normal way to annotate tree will cause unknown annotation
treeprofiler annotate \
-t missing_gtdb_v202.tree \
--taxon-column name \
--taxadb gtdb \
--gtdb-version 202 \
-o ./

python show_tree_props.py missing_gtdb_v202_annotated.nw
Target tree internal node Root contains the following properties:  
{
'common_name': '', 
'evoltype': 'S', 
'lca': '',  
'name': 'Root', 
'named_lineage': '', 
'rank': 'Unknown', 
'sci_name': 'None', 
'species': 'Taxa_2|GB_GCA_003344655.1|RS_GCF_000019605.1|Taxa_1',
 'taxid': 'None'
 }
Target tree leaf node contains the following propertiies:  
{
'name': 'Taxa_1', 
'dist': 1.0, 
'common_name': '', 
'named_lineage': '', 
'rank': 'Unknown', 
'sci_name': '', 
'species': 'Taxa_1', 
'taxid': 'Taxa_1'
}

# now adding --ignore-unclassified
treeprofiler annotate \
-t missing_gtdb_v202.tree \
--taxon-column name \
--taxadb gtdb \
--gtdb-version 202 \
--ignore-unclassified \
-o ./

python show_tree_props.py missing_gtdb_v202_annotated.nw
Target tree internal node Root contains the following properties:  
{
'common_name': '', 
'evoltype': 'S', 
'lca': 'superkingdom-d__Archaea|phylum-p__Thermoproteota|class-c__Korarchaeia|order-o__Korarchaeales|family-f__Korarchaeaceae|genus-g__Korarchaeum', 
'name': 'Root',
'named_lineage': 'root|d__Archaea|p__Thermoproteota|c__Korarchaeia|o__Korarchaeales|f__Korarchaeaceae|g__Korarchaeum', 
'rank': 'genus', 
'sci_name': 'g__Korarchaeum', 
'species': 'Taxa_1|RS_GCF_000019605.1|GB_GCA_003344655.1|Taxa_2', 
'taxid': 'g__Korarchaeum'
}
Target tree leaf node contains the following propertiies:  
{
'name': 'Taxa_1', 
'dist': 1.0, 
'common_name': '', 
'named_lineage': '', 
'rank': 'Unknown', 
'sci_name': '', 
'species': 'Taxa_1', 
'taxid': 'Taxa_1'
}
```

## Arguments for Functional Annotation

| Argument | Description | Examples | Notes |
| --- | --- | --- | --- |
| --emapper-annotations EMAPPER_ANNOTATIONS | attach eggNOG-mapper output out.emapper.annotations |  |  |
| --emapper-pfam EMAPPER_PFAM | attach eggNOG-mapper pfam output out.emapper.pfams |  |  |
| --emapper-smart EMAPPER_SMART | attach eggNOG-mapper smart output out.emapper.smart |  |  |
| --alignment ALIGNMENT | Sequence alignment, .fasta format |  |  |

### Alignment annotation

treeprofiler will can anntotate msa to tree and automatically calculate the consesus sequence in the internal node (fixed threshold 0.7), alignment will stored in nodes with property name `alignment`. Using `--column-summary-method alignment=none` can switch off the function for calculating consensus sequence for internal nodes.

```bash
# annotate alignment
treeprofiler annotate --tree COG1348.tree --alignment COG1348.faa.aln

# mute consensus sequence
treeprofiler annotate \
--tree COG1348.tree \
--alignment COG1348.faa.aln \
--column-summary-method alignment=none \
-o ./
```

### Domain annotation

treeprofiler need to attach pfam annotation from emapper and alignment to target tree

```bash
treeprofiler annotate \
--tree COG1348.tree \
--emapper-pfam COG1348.out.emapper.pfam \
--alignment COG1348.faa.aln \
-o ./
```

### Functional annotation from emapper

emapper annotation output and the summary method

| Field | datatype | summary method |
| --- | --- | --- |
| seed_ortholog | str | counter |
| evalue | float | descriptive stat |
| score | float | descriptive stat |
| eggNOG_OGs | list | counter |
| max_annot_lvl | str | counter |
| COG_category | str | counter |
| Description | str | counter |
| Preferred_name | str | counter |
| GOs | list | counter |
| EC | str | counter |
| KEGG_ko | list | counter |
| KEGG_Pathway | list | counter |
| KEGG_Module | list | counter |
| KEGG_Reaction | list | counter |
| KEGG_rclass | list | counter |
| BRITE | list | counter |
| KEGG_TC | list | counter |
| CAZy | list | counter |
| BiGG_Reaction | list | counter |
| PFAMs | list | counter |

```bash
treeprofiler annotate \
--tree COG1348.tree \
--emapper-annotation COG1348.out.emapper.annotations 
-o ./
```

## Arguments for analytic method

### Ancestral character reconstruction

Quick start

```bash
cd 01_annotate/analytic_annotation

ls 
Albanian.tree.152tax.nwk metadata_tab.csv

# check metadata
head metadata_tab.csv
id	Country
98CMAJ6932	Africa
98CMAJ6933	Africa
96CMAJ6134	Africa
00SEAY5240	WestEurope
97CDAF6240	Africa
97CDAF6238	Africa

# quick running using all default setting
treeprofiler annotate \
-t Albanian.tree.152tax_annotated.nw \
--internal-parser name \
--acr-discrete-columns Country  \
-o ./

# check properties
python show_tree_props.py Albanian.tree.152tax_annotated.nw
Target tree internal node Root contains the following properties:  
{
'name': 'ROOT', 
'dist': 0.0, 
'Country': 'Africa', 
'Country_counter': 'Africa--50||Albania--31||EastEurope--10||Greece--39||WestEurope--22'
}
Target tree leaf node 97CDAF6238 contains the following propertiies:  
{
'name': '97CDAF6238', 
'dist': 0.08034, 
'Country': 'Africa'
}

# check output files
head marginal_probabilities.character_Country.model_F81.tab
node	Africa	Albania	EastEurope	Greece	WestEurope
ROOT	0.9462054466377042	0.0019142742715016286	0.011256165797407233	0.013434856612985015	0.027189256680401872
node_1	0.9497450729621073	0.00018867741670758483	0.00048818236055906636	0.001324183303131325	0.04825388395749479
node_2	0.9752818930521312	0.00048506476303705997	0.015213913144468159	0.0034043477773810613	0.0056147812629824085
node_3	0.9473989345272481	0.0002801019197914036	0.0005949760547048478	0.001965821926394849	0.04976016557186095
node_4	0.9384942099527859	0.0002164578877048098	0.00043984526187224396	0.00151915289715353	0.05933033400048369
00CZAY4286	0.0	0.0	1.0	0.0	0.0
node_5	0.9999517018762923	9.117741186968884e-07	3.0195194146220156e-05	6.458698485629717e-06	1.0732456957024559e-05
97CDAF6238	1.0	0.0	0.0	0.0	0.0
94CYAF6237	0.0	0.0	0.0	0.0	1.0

# check output files
head params.character_Country.method_MPPA.model_F81.tab
parameter	value
pastml_version	1.9.42
character	Country
log_likelihood	-118.96060539505257
log_likelihood_restricted_JOINT	-123.17363108674806
log_likelihood_restricted_MAP	-123.3244296265415
log_likelihood_restricted_MPPA	-120.52779174042388
num_scenarios	96
num_states_per_node_avg	1.023102310231023
num_unresolved_nodes	6
```

`--acr-discrete-columns {PROP}`  allow users to calculate the ancestral character state construction via pastml package. Hence the internal node will be infered the state based on the children leaf node metadata. Users can choose the prediction method using `--prediction-method {METHOD}`. It will generate the output config file from PASTML package as 

`params.character_{prop}.method_{method}.model_{model}.tab` which contains information of likelihood from different model/method.

**MAXIMUM LIKELIHOOD (ML) METHODS**

ML approaches are based on probabilistic models of character evolution along tree branches. From a theoretical standpoint, ML methods have some optimality guaranty [Zhang and Nei, 1997, Gascuel and Steel, 2014], at least in the absence of model violation. Noted that running this ML method will generate output file as `marginal_probabilities.character_<prop>.model_{model}.tab` which contain the calculated propabilities of each character in every internal nodes. Instead **MP method** won’t generate it because it doesn’t compute the marginal propabilities

We provide three ML methods: maximum a posteriori (MAP), Joint, and marginal posterior probabilities approximation (MPPA, recommended):

`MPPA`(default)

`MAP`

`JOINT`

`ML` 

**Character evolution models (only in ML methods)**

We provide some models of character evolution that differ in the way the equilibrium frequencies of states are calculated: `JC`, `F81` *(recommended)*, and `EFT` (estimate-from-tips, *not recommended*). Using `--prediction-method {model}` to set up.

**MAXIMUM PARSIMONY (MP) METHODS**

`DOWNPASS`

`DELTRAN`

`ACCTRAN`

`MP`

| Argument | Description | examples | Notes | comments |
| --- | --- | --- | --- | --- |
| --acr-discrete-columns ACR_DISCRETE_COLUMNS [ACR_DISCRETE_COLUMNS ...] | <col1> <col2> names to perform acr analysis for discrete traits | examples: (https://www.notion.so/examples-31132caaf38f4c8f86c591433f7ccb80?pvs=21)  |  |  |
| --prediction-method | Prediction method for ACR discrete analysis. Options: MPPA, MAP, JOINT, DOWNPASS, ACCTRAN, DELTRAN, COPY, ALL, ML, MP. [Default: MPPA] | examples: (https://www.notion.so/examples-31132caaf38f4c8f86c591433f7ccb80?pvs=21)  | DOWNPASS, ACCTRAN, DELTRAN wont calculate marginal propabilty of each state in ancestral node. |  |
| --model | Evolutionary model for ML methods in ACR discrete analysis. Options: JC, F81, EFT, HKY, JTT, CUSTOM_RATES. [Default: F81] | examples: (https://www.notion.so/examples-31132caaf38f4c8f86c591433f7ccb80?pvs=21)  |  |  |
| --threads | Number of threads to use for annotation. [Default: 4] |  |  |  |

examples:

```bash

# using different model
treeprofiler annotate \
-t Albanian.tree.152tax.nwk \
--internal-parser name \
--metadata metadata_tab.csv \
--acr-discrete-columns Country \
--prediction-method MPPA \
--model JC \
--threads 6 \
-o ./

python show_tree_props.py Albanian.tree.152tax_annotated.nw
Target tree internal node Root contains the following properties:  
{
'name': 'ROOT',
'dist': 0.0, 
'Country': 'Africa', 
'Country_counter': 'Africa--50||Albania--31||EastEurope--10||Greece--39||WestEurope--22'
}
Target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': '97CDAF6238', 
'dist': 0.08034, 
'Country': 'Africa'
}

# using MP methods (no calculation of ancestral propababilities)
treeprofiler annotate \
-t Albanian.tree.152tax.nwk \
--internal-parser name \
--metadata metadata_tab.csv \
--acr-discrete-columns Country \
--prediction-method DOWNPASS \
--threads 6 \
-o ./

python show_tree_props.py Albanian.tree.152tax_annotated.nw
Target tree internal node Root contains the following properties:  
{
'name': 'ROOT',
'dist': 0.0, 
'Country': 'Africa', 
'Country_counter': 'Africa--50||Albania--31||EastEurope--10||Greece--39||WestEurope--22'
}
Target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': '97CDAF6238', 
'dist': 0.08034, 
'Country': 'Africa'
}
```

### Phylogenetic signal delta statistic

Running signal delta statistic required running Ancestral Character Reconstruction using MPPA or MP methods in order to have the ancestral character propabilities. Calculated delta statistic metric and p_value of given trait will be stored in root node as properties. 

| Argument | Description | examples | comment |
| --- | --- | --- | --- |
| --delta-stats | Calculate delta statistic for discrete traits in ACR analysis, ONLY for MPPA or MAP prediction method. [Default: False] | Delta statistic Examples (https://www.notion.so/Delta-statistic-Examples-c781c94a16dd4866b3ac0a4241352f7a?pvs=21)  |  |
| --ent-type | Entropy method to measure the degree of phylogenetic signal between discrete trait and phylogeny. Options: LSE, SE, GINI. [Default: SE] for Shannon Entropy, other options are GINI for Gini impurity and LSE for Linear Shannon Entropy. |  |  |
| --iteration | Number of iterations for delta statistic calculation. [Default: 10000] |  |  |
| --lambda0 | Rate parameter of the delta statistic calculation.
[Default: 0.1] |  |  |
| --se | Standard deviation of the delta statistic calculation.
[Default: 0.5] |  |  |
| --thin | Keep only each xth iterate.
[Default: 10] |  |  |
| --burn | Burned-in iterates.
[Default: 100] |  |  |

Delta statistic Examples

```bash
treeprofiler annotate \
-t Albanian.tree.152tax.nwk \
--internal-parser name \
--metadata metadata_tab.csv \
# acr to obtain propabilities
--acr-discrete-columns Country \
--prediction-method MPPA \
--model F81 \
# delta statistic
--delta-stats \
--ent-type SE \
--iteration 10000 -\
--lambda0 0.1 \
--se 0.5 \
--thin 10 \
--burn 100 \
-o ./

# delta metric and p_val stored in root node
python show_tree_props.py Albanian.tree.152tax_annotated.nw
Target tree internal node Root contains the following properties:  
{
'name': 'ROOT', 
'dist': 0.0, 
'Country': 'Africa', 
'Country_counter': 'Africa--50||Albania--31||EastEurope--10||Greece--39||WestEurope--22', 
'Country_delta': '19.52340888828994', 
'Country_pval': '0.0'
}
Target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': '97CDAF6238', 
'dist': 0.08034, 
'Country': 'Africa'
}
```

### Lineage Specificity Analysis

Using `--ls-columns {prop_name}`   to start the lineage  specificity analysis, the given trait need to be boolean value such as `True`; `False`; `yes`; `no`; `t`; `f`; `1`; `0`;  which fit the criteria in treeprofiler annotate. Calculated results will be stored in each internal nodes with suffix of `_prec` , `_sens` and `_f1`.

| Argument | Description | examples | Comments |
| --- | --- | --- | --- |
| --ls-columns LS_COLUMNS [LS_COLUMNS ...] | <col1> <col2> names to perform lineage specificity analysis | Examples: (https://www.notion.so/Examples-36e8aaed0abe4d369379f4825d1d69e9?pvs=21)  |  |
| --prec-cutoff | Precision cutoff for lineage specificity analysis. [Default: 0.95] | Examples: (https://www.notion.so/Examples-36e8aaed0abe4d369379f4825d1d69e9?pvs=21)  |  |
| --sens-cutoff | Sensitivity threshold for lineage specificity analysis. [Default: 0.95] | Examples: (https://www.notion.so/Examples-36e8aaed0abe4d369379f4825d1d69e9?pvs=21)  |  |

Examples:

```bash
# in the example we loose the cutoff to 0.5
treeprofiler annotate \
-t demo2.tree \
-d demo2_ls.tsv \
--ls-columns profile1 \
--prec-cutoff 0.5 \
--sens-cutoff 0.5 \
-o ./

# check properties 
python show_tree_props.py demo2_annotated.nw
Target tree internal node Root contains the following properties:  
{
'name': 'Root', 
'profile1_counter': 'False--33||True--7', 
'profile1_f1': '0.2978723404255319', 
'profile1_prec': '0.175', 
'profile1_sens': '1.0'
}
Target tree leaf node Taxa_0 contains the following propertiies:  
{
'name': 'Taxa_3', 
'dist': 0.315846, 
'profile1': 'False'
}

```

# `plot`

`plot` subcommand is about how users want to visualize the annotated metadata from taget tree.

## **Quick start**

we use example from `basic/` , which contain all kind of datatype

```bash
head metadata.tsv 
#name	col1	col2	col3	col4	col5	col6	col7	col8	col9	col10	col11
Phy003I7ZJ_CHICK	0.05	0.12	0.86	0.01	0.69	medium	1	True	97	w,t,t	50
Phy0054BO3_MELGA	0.64	0.67	0.51	0.29	0.14	medium	1	True	16	r,q,s	245
Phy00508FR_NIPNI	0.89	0.38	0.97	0.49	0.26	low	1	False	87	z,f,p	122

# annotation
treeprofiler annotate -t basic_example1.nw -d metadata.tsv -o ./

treeprofiler plot \
--tree basic_example1_annotated.ete \
--rectangle-layout col6 \
--binary-layout col7 \
--heatmap-layout col1 col2 col3 \
--barplot-layout col9 col11 \
--profiling-layout col10
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%201.png)

## **Arguments of general setting for layouts**

Selected properties of tree will be visualized at the aligned panel alongside with the tree, here is some basic parameters for layouts.

| Argument | Description | Examples | Notes | Comments |
| --- | --- | --- | --- | --- |
| --column-width | Column width of each property in layout which shown in aligned panel. [default: 20]. | Examples with basic parameters: (https://www.notion.so/Examples-with-basic-parameters-7de7ed7d79234936bd84bd9dd7a849bb?pvs=21)  | Applied ONLY in layouts which shown in aligned panel |  |
| --padding-x | Customize horizontal column padding distance of each layout in aligned panel. [default: 1] | Examples with basic parameters: (https://www.notion.so/Examples-with-basic-parameters-7de7ed7d79234936bd84bd9dd7a849bb?pvs=21)  | Applied ONLY in layouts which shown in aligned panel |  |
| --padding-y | Customize vertical padding distance of each layout in aligned panel..[default: 0]. |  |  |  |

Examples with basic parameters:

```bash
# change column width from default 20 px to 50px
# padding x from default 1 to 5
treeprofiler plot \
--tree basic_example1_annotated.ete \
--rectangle-layout col6 \
--binary-layout col7 \
--heatmap-layout col1 col2 col3 \
--profiling-layout col10 \
--column-width 50 \
--padding-x 5
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%202.png)

## **Arguments of layouts for categorical data**

| Argument | Description | Leaf node | Internal node | Examples | Rectangular/Circular Tree layout | Comments |
| --- | --- | --- | --- | --- | --- | --- |
| --label-layout LABEL_LAYOUT [LABEL_LAYOUT ...] | <prop1> <prop2> names of properties where values will be displayed on the aligned panel. | TextFace | Stacked Horizontal RecFace (only collapsed) | Label Layout (https://www.notion.so/Label-Layout-4fa2e939ad9f40a8b98e4af1e379e7df?pvs=21)  | both |  |
| --rectangle-layout RECTANGLE_LAYOUT [RECTANGLE_LAYOUT ...] | <prop1> <prop2> names of properties where values will be labeled as rectangular color blocks on the aligned panel. | RecFace | Stacked Horizontal RecFace (only collapsed) | Rectangle Layout (https://www.notion.so/Rectangle-Layout-39fb8847e505462b8fb83da424a9dcf6?pvs=21)  | both |  |
| --colorbranch-layout COLORBRANCH_LAYOUT [COLORBRANCH_LAYOUT ...] | <prop1> <prop2> names of properties where branches will be colored based on different values. | Branch with color | Stacked Horizontal RecFace (only collapsed) | ColorBranch Layout (https://www.notion.so/ColorBranch-Layout-7d1043fec2ee41cda65dd6bdf9205646?pvs=21)  | both |  |
| --background-layout BACKGROUND_LAYOUT [BACKGROUND_LAYOUT ...] | <prop1> <prop2> names of properties where values will be labeled as rectangular color blocks on the aligned panel. | Background with color | Stacked Horizontal RecFace (only collapsed) | Background Layout (https://www.notion.so/Background-Layout-41a8678bb8754073bfb3015001fb4d4c?pvs=21)  | both |  |
| --piechart-layout PIECHART_LAYOUT [PIECHART_LAYOUT ...] | <prop1> <prop2> names of properties whose internal nodes need to be plotted as piechart-layout. | None | PiecharFace | Piechart Layout (https://www.notion.so/Piechart-Layout-733338a1949b430d8709a20a2dcf533f?pvs=21)  | both |  |
| --profiling-layout PROFILING_LAYOUT [PROFILING_LAYOUT ...] | <prop1> <prop2> names of properties which need to be converted to a presence-absence profiling matrix of each value. | presence/absence matrix;
Array from ete4 | gradient of presence/total heatmap (only collapsed) | Profiling Layout (https://www.notion.so/Profiling-Layout-132d7dd287fd42edbc4661fd54f52eb8?pvs=21)  | Rectangular |  |
| --categorical-matrix-layout CATEGORICAL_MATRIX_LAYOUT [CATEGORICAL_MATRIX_LAYOUT ...] | <prop1> <prop2> names which need to be plotted as categorical_matrix_layout for categorical values. | array from ete4 | None | Categorical Matrix Layout (https://www.notion.so/Categorical-Matrix-Layout-5df88357f2fd4ef8b975c801a7cb325f?pvs=21)  | Rectangular |  |

### **Label Layout**

`--label-layout` shows the property of leaf by text on the aligned channel, when collapsed, aligned panel shows the horizontal stacked bar to demostrate the composition of each variable.

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--label-layout col6
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%203.png)

### **Rectangle Layout**

`--rectangle-layout` will assign a color to each variable under the property, displaying as colored rectangle in aligned panel, when internal branches collapsed,  aligned panel shows the horizontal stacked bar to demostrate the composition of each variable.

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--rectangle-layout col6
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%204.png)

### **ColorBranch Layout**

`--colorbranch-layout` will assign a color to each variable under the property, displaying as colored branch of corresponding node.

Noted that in this case from leaf to root, if node contains the given property, it will still have the colored branch. 

```bash
# every node share the property "name"
treeprofiler plot \
-t basic_example1_annotated.ete \
--colorbranch-layout name
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%205.png)

If internal node doesn’t have the given property, once it collapsed,  aligned panel shows the horizontal stacked bar to demostrate the composition of each variable.

```bash
# show normal counter 
treeprofiler plot \
-t basic_example1_annotated.ete \
--colorbranch-layout col6
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%206.png)

### **Background Layout**

`--background-layout` works just like `--colorbranch-layout` , the only difference is `--background-layout` visualize the background of the corresponding node instead of the branch color. It is useful and more visual when the tree is large.

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--background-layout col6
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%207.png)

### **Piechart Layout**

`--piechart-layout` is unique layout designed for visualize internal nodes which contain counter of the given property from children nodes. 

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--piechart-layout col6
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%208.png)

### **Profiling Layout**

`--profiling-layout` will convert categorical trait regardless `str` or `list` into presence-absence matrix. Importantly, once it collapsed, aligned matrix will show the gradient of presence/total of corresponding trait. This layout using `draw_array` from ete4 therefore it’s suitable for large scale

**single value example**

```bash
# check in metadata
awk '{print $1,$7}' metadata.tsv |head
#name col6
Phy003I7ZJ_CHICK medium
Phy0054BO3_MELGA medium
Phy00508FR_NIPNI low
Phy004O1E0_APTFO medium
Phy004PA1B_ANAPL medium

treeprofiler plot \
-t basic_example1_annotated.ete \
--profiling-layout col6
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%209.png)

**List value example**

```bash
# check in metadata
awk '{print $1,$11}' metadata.tsv |head
#name col10
Phy003I7ZJ_CHICK w,t,t
Phy0054BO3_MELGA r,q,s
Phy00508FR_NIPNI z,f,p
Phy004O1E0_APTFO z,t,b
Phy004PA1B_ANAPL z,r,p
Phy004TLNA_APAVI u,e,i
Phy004OLZM_COLLI u,w,v

# convert each letter into presence/absence matrix
treeprofiler plot \
-t basic_example1_annotated.ete \
--profiling-layout col11
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2010.png)

### **Categorical Matrix Layout**

`--categorical-matrix-layout` is similar to `--rectangle-layout` , which shows color block to represent the variable. But `--rectangle-layout` take **EACH** given column as one individual case as one layout, `--categorical-matrix-layout` take **ALL** given columns as one case to one layout.

This layout using `draw_array` from ete4 therefore it’s suitable for large scale.

## **Arguments of Layouts for boolean data**

| Argument | Description | Leaf node | Internal node | Example | Rectangular/Circular Tree layout | Comment |
| --- | --- | --- | --- | --- | --- | --- |
| --binary-layout BINARY_LAYOUT [BINARY_LAYOUT ...] | <prop1> <prop2> names of properties which need to be plotted as binary-layout which highlights the positives. Each column has different colors.
Internal node represent ratio of true/total gradient. | positive/negative RectFace | Gradient RectFace | Binary Layout (https://www.notion.so/Binary-Layout-a32a371047424b609151f013267948fd?pvs=21)  | both |  |
| --binary-aggregate-layout BINARY_AGGREGATE_LAYOUT [BINARY_AGGREGATE_LAYOUT ...] | <prop1> <prop2> names of properties which need to be plotted as binary-aggregate-layout which highlights the positives.
Each column has different colors.
Internal node present the accumulated counts of true and represent on color | positive/negative RectFace | Accumulated RectFace | Binary Aggregate Layout  (https://www.notion.so/Binary-Aggregate-Layout-340e0b35a8254ff3ba028409c54559ef?pvs=21)  | both |  |
| --binary-unicolor-layout BINARY_UNICOLOR_LAYOUT [BINARY_UNICOLOR_LAYOUT ...] | <prop1> <prop2> names of properties which need to be plotted as binary-layout which highlights the positives.
Each column has same colors.
Internal node represent ratio of true/total gradient. | positive/negative RectFace | Gradient RectFace | Binary Unicolor Layout (https://www.notion.so/Binary-Unicolor-Layout-740a1c63787a4df2baf6e8d09744eb8d?pvs=21)  | both |  |
| --binary-unicolor-aggregate-layout BINARY_UNICOLOR_AGGREGATE_LAYOUT [BINARY_UNICOLOR_AGGREGATE_LAYOUT ...] | <prop1> <prop2> names of properties which need to be plotted as binary-aggregate-layout which highlights the positives.
Each column has same colors.
Internal node present the accumulated counts of true and represent on color | positive/negative RectFace | Accumulated RectFace | Binary Unicolor Aggregate Layout (https://www.notion.so/Binary-Unicolor-Aggregate-Layout-b181390618ee43d29ad4eb6152bf9325?pvs=21)  | both |  |
| --binary-matrix-layout BINARY_MATRIX_LAYOUT [BINARY_MATRIX_LAYOUT ...] | <prop1> <prop2> names of properties which need to be plotted as binary-matrix which highlights the positives.
Each column has same colors.
Internal node represent ratio of true/total gradient. 
Suitable for large scale (>100 columns)  | Array from ete4 | Gradient RectFace | Binary Matrix Layout (https://www.notion.so/Binary-Matrix-Layout-bb5775018d114f37be1d76ffa9c86416?pvs=21)  | Rectangular |  |

### **Binary Layout**

`--binary-layout` highlights the positives. Each column has **different** colors. Internal node represent ratio of **true/total gradient.**

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--binary-layout col7 col8
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2011.png)

### **Binary Aggregate Layout**

`--binary-aggregate-layout` highlights the positives. Each column has **different** colors. Internal node present the **accumulated counts of true** and represent on color

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--binary-aggregate-layout col7 col8
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2012.png)

### **Binary Unicolor Layout**

`--binary-unicolor-layout`  Each column has **same** colors. Internal node represent ratio of **true/total gradient.**

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--binary-uniclor-layout col7 col8
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2013.png)

### **Binary Unicolor Aggregate Layout**

`--binary-unicolor-aggregate-layout` Each column has **same** colors. Internal node present the **accumulated counts of true** and represent on color. 

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--binary-unicolor-aggregate-layout col7 col8
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2014.png)

### **Binary Matrix Layout**

`--binary-matrix-layout` is similar to `--binary-layout` but using `draw_array` from ete4 therefore it’s suitable for large scale. 

But the limit is only work on rectangular tree

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--binary-matrix-layout col7 col8
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2015.png)

## **Arguments of Layouts for Numerical data**

| Argument | Description | Applied on data-matrix (file)? | Applied on negative data? | Example | Rectangular/Circular Tree layout | Comments |
| --- | --- | --- | --- | --- | --- | --- |
| --colorbranch-layout COLORBRANCH_LAYOUT [COLORBRANCH_LAYOUT ...] | <prop1> <prop2> names of properties where branches will be colored based on different values. | no | yes | ColorBranch Layout (https://www.notion.so/ColorBranch-Layout-3c18405742e44e788a59cbb0b4ec6664?pvs=21)  | both |  |
| --bubble-layout BUBBLE_LAYOUT [BUBBLE_LAYOUT ...] | (experimental) <prop1> <prop2> names of properties which need to be plotted as bubble-layout. | no | yes | Bubble Layout (https://www.notion.so/Bubble-Layout-b40b0af51f8d4f4584ab2d5c95d18720?pvs=21)  | both |  |
| --heatmap-layout HEATMAP_LAYOUT [HEATMAP_LAYOUT ...] | <prop1> <prop2> names of numerical properties which need to be read as heatmap-layout. | no | yes | Heatmap Layout  (https://www.notion.so/Heatmap-Layout-d49f072de6fd43cd91bd807a66e3e885?pvs=21)  | both |  |
| --heatmap-mean-layout HEATMAP_MEAN_LAYOUT [HEATMAP_MEAN_LAYOUT ...] | <prop1> <prop2> names of numerical properties which need to be read as heatmap-layout. | no | yes | Heatmap Layout  (https://www.notion.so/Heatmap-Layout-d49f072de6fd43cd91bd807a66e3e885?pvs=21)  | both |  |
| --heatmap-zscore-layout HEATMAP_ZSCORE_LAYOUT [HEATMAP_ZSCORE_LAYOUT ...] | <prop1> <prop2> names of numerical properties which need to be read as heatmap-layout. | no | yes | Heatmap Layout  (https://www.notion.so/Heatmap-Layout-d49f072de6fd43cd91bd807a66e3e885?pvs=21)  | both |  |
| --barplot-layout BARPLOT_LAYOUT [BARPLOT_LAYOUT ...] | <prop1> <prop2> names of numerical properties which need to be read as barplot_layouts. | no | no | Barplot Layout (https://www.notion.so/Barplot-Layout-8d51891bfe974fdeb32d1832a64224e4?pvs=21)  | both |  |
| --barplot-width  | setting barplot length [default: 200] |  |  | Barplot Layout (https://www.notion.so/Barplot-Layout-8d51891bfe974fdeb32d1832a64224e4?pvs=21)  |  |  |
| --barplot-scale <prop1>  | using certain prop as the barplot scale for all of the barplot. [default: None] |  |  | Barplot Layout (https://www.notion.so/Barplot-Layout-8d51891bfe974fdeb32d1832a64224e4?pvs=21)  |  |  |
| --numerical-matrix-layout NUMERICAL_MATRIX_LAYOUT [NUMERICAL_MATRIX_LAYOUT ...] | numerical matrix that takes into account ALL values into gradient from white to red. <prop1> <prop2> names which need to be plotted as numerical_matrix_layout for numerical values. | yes | yes | Numerical Matrix Layout (https://www.notion.so/Numerical-Matrix-Layout-c001bf56e3874464ae0059f3caf199d9?pvs=21)  | Rectangular |  |

### **ColorBranch Layout**

`--colorbranch-layout` can detect if property is numerical data, then will color the branch based on color scale from minimum to maximum, including branches from the internal nodes. If internal nodes contain the corresponding property, then the relative value will be the representative; If not that the value will be the summarized value from descriptive statistic

Colorbranch with property that share from leaf to root:

```bash
# all nodes have dist value
treeprofiler plot \
-t basic_example1_annotated.ete \
--colorbranch-layout dist

# only internal nodes have support value
treeprofiler plot \
-t basic_example1_annotated.ete \
--colorbranch-layout support
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2016.png)

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2017.png)

Colorbranch with summarized property (avg will be the representative value of internal nodes)

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--colorbranch-layout col11
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2018.png)

**Bubble Layout**

`--bubble-layout` will scale the given absolute value property as size of bubble. Noted that if value is negative, bubble will be blue, otherwise bubble is red. 

If internal nodes contain the corresponding property, then the relative value will be the representative; If not that the value will be the summarized value from descriptive statistic.

Bubble with property that share from leaf to root:

```bash
treeprofiler plot -t basic_example1_annotated.ete --bubble-layout dist
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2019.png)

Bubble with summarized property with negative value (avg will be the representative value of internal nodes)

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--bubble-layout col1
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2020.png)

### **Heatmap Layout**

A series of heatmap layout is only the matter how to normalize the value to show the gradient of color. 

`--heatmap-layout`  values will be normalized between 0 and 1 (minimu, maximum)

`--heatmap-mean-layout` values will be normalized between -1 and 1 by using the formula (val-mean)/(max-min)

`--heatmap-zscore-layout`  values will be Z-score normalized by using the formula (val-mean)/std

reference

[https://itol.embl.de/help.cgi#heatmap](https://itol.embl.de/help.cgi#heatmap)

`--heatmap-layout`

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--heatmap-layout col1 col2 col3 col4 col5
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2021.png)

`--heatmap-mean-layout`

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--heatmap-mean-layout col1 col2 col3 col4 col5
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2022.png)

`--heatmap-zscore-layout` 

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--heatmap-zscore-layout col1 col2 col3 col4 col5
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2023.png)

### **Barplot Layout**

`--barplot-layout` will show barplot of numerical color. **Noted that negative value won’t show in barplot**

```bash
treeprofiler plot \
-t basic_example1_annotated.ete \
--barplot-layout col1 col2 col3 col4 col5
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2024.png)

Using `--barplot-width` and `--barplot-scale` can help with different setting of barplot.

`--barplot-scale` can use one certain prop to set the scale of all barplot in order to facilitate the cross column comparison.

```bash
# two different columns with differen value in same scale (default)
 treeprofiler plot \
 -t basic_example1_annotated.ete \
 --barplot-layout col9 col11
 
 # two different columns using col9 as scale to cross compare with col11
 treeprofiler plot \
 -t basic_example1_annotated.ete \
 --barplot-layout col9 col11 \
 --barplot-scale col9
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2025.png)

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2026.png)

### **Numerical Matrix Layout**

`--numerical-matrix-layout` is similar to `--heatmap-layout`, but using `draw_array` from ete4, therefore it can handle large scale of data, and also visualize data matrix which was stored as a file in previous annotation step.

Here we use different example:

```bash
head data.array
Taxa_0,-2.591,1.937,-3.898,0.447,-1.349
Taxa_1,3.366,-1.871,4.362,1.585,-2.479
Taxa_2,0,-0.098,0,-3.326,2.746
Taxa_3,3.671,-0.947,-4.509,-3.131,-2.194
Taxa_4,0.676,-2.356,-4.825,0.115,0

#Annotate data.array column by column
treeprofiler annotate \
-t demo1.tree \
--metadata data.array \
--no-headers \
-sep , \
-o ./

# visualize each column using numerical matrix
treeprofiler plot \
-t demo1_annotated.ete \
--numerical-matrix-layout col1 col2 col3 col4 col5

# Or annotate data.array as a data matrix file
treeprofiler annotate \
-t demo1.tree \
--data-matrix data.array \
-sep , \
-o ./

# now data.array is a property
treeprofiler plot \
-t demo1_annotated.ete \
--numerical-matrix-layout data.array
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2027.png)

 

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2028.png)

## **Arguments of Layouts for Analytic data**

| Argument | Description | Example | Comments |
| --- | --- | --- | --- |
| --acr-discrete-layout ACR_DISCRETE_LAYOUT [ACR_DISCRETE_LAYOUT ...] | <prop1> <prop2> names of properties which need to be plotted as acr-discrete-layout. | Ancestral Character Reconstruction Layout  (https://www.notion.so/Ancestral-Character-Reconstruction-Layout-8024f28138684ca09ec6d6fc136651f6?pvs=21)  |  |
| --ls-layout LS_LAYOUT [LS_LAYOUT ...] | <prop1> <prop2> names of properties which need to be plotted as ls-layout. | Lineage Specificity Layout (https://www.notion.so/Lineage-Specificity-Layout-93574f3c108c4e4b958f212b8bb6cf61?pvs=21)  |  |

### Ancestral Character Reconstruction Layout

`--acr-discrete-layout` is the layout designed for visualizing annotated tree of acr from previous annotate step or manual annotation. Noted that if phylogenetic signal test `--delta-stats` was executed, delta stat metric and p_value will be showed next to the root node. 

The infered character of each internal node will be shown as colorbranch, including the uncertain character

```bash
# we use tree from previous step 
cd analytic/

treeprofiler plot \
-t Albanian.tree.152tax_annotated.nw \
--acr-discrete-layout Country \
--internal-parser name
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2029.png)

### Lineage Specificity Layout

`--ls-layout` is used to visualized the output tree which was executed with `--ls-columns` in previous annotate step. Noted that Lineage Specificity Calculation computes three metric, which is:

- `_f1`: f1 score
- `_prec`: trait percision
- `_sens`: trati sensitivity

Therefore the visulization will generate three layouts for each metrix shown in colorbranch with the score, plus highlighting the clade as lineage specific clade of given trait which passed the `--prec-cutoff` and `--sens-cutoff` in previous step.

```bash
 # we use tree from previous step 
cd analytic/

treeprofiler plot -t demo2_annotated.nw --ls-layout profile1
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2030.png)

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2031.png)

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2032.png)

**Arguments of Layouts for multiple sequence alignment**

In order to visualize multiple sequence alignment alongside with the tree, first we need to annotate alignment using `--alignment` in `annotate`. Then activate alignment layout by adding `--alignment-layout`. Consensus sequence (if calculated) will shown once internal nodes collapsed.

| Argument | Description | Example | Comments |
| --- | --- | --- | --- |
| --alignment-layout | Display Multiple Sequence Alignment layout in aligned panel. | Arguments of Layouts for multiple sequence alignment (https://www.notion.so/Arguments-of-Layouts-for-multiple-sequence-alignment-694ad393a9c24849a487742aa153f4e0?pvs=21)  |  |

Using functional annotation examples from previous step

```bash
cd functional/

treeprofiler plot -t COG1348_annotated.ete --alignment-layout
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2033.png)

**Arguments of Layouts for eggnog-mapper pfam/smart annotations**

| Argument | Description | Example | Comment |
| --- | --- | --- | --- |
| --domain-layout | Activate domain_layout which displays protein domain annotation in sequence. | Arguments of Layouts for eggnog-mapper pfam/smart annotations (https://www.notion.so/Arguments-of-Layouts-for-eggnog-mapper-pfam-smart-annotations-98160f1bcafb4089af4d000e4b0e7f23?pvs=21)  |  |

Once tree is annotated, using `--domain-layout` to visualize it. Noted that domain only show on leaf node, not in internal nodes because there is no consensus domain yet.

```bash
cd functional/

treeprofiler plot -t COG1348_annotated.ete --domain-layout
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2034.png)

**Arguments of Layouts for eggnog-mapper functional annotations**

| Argument | Description | Example | Comments |
| --- | --- | --- | --- |
| --emapper-layout | Activate emapper_layout which displays all the annotation from EggNOG-mapper. |  |  |

If metadata is output from eggnog-mapper, using `--emapper-annotations` automatically parse all information as metadata. Program will parse data of all the columns from emapper output. Once tree is annotated, using `--emapper-layout` to visualize tree with all the metadata. Each column, based on the difference of datatype, will be visualized in different layouts

```bash
cd functional/
treeprofiler plot -t COG1348_annotated.ete --emapper-layout --column-width 70
```

Generic metadata

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2035.png)

Functional profiling (kegg, ko, gos, etc), collapsed internal nodes shown gradient of presence/total percentage.

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2036.png)

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2037.png)

## **Arguments of Layouts for Taxonomic data**

| Argument | Description | Example | Comments |
| --- | --- | --- | --- |
| --taxonclade-layout | Activate taxonclade-layout which clades will be colored based on taxonomy of each node. | TaxonClade Layout (https://www.notion.so/TaxonClade-Layout-a6f53207f21f4a12ae0671873dc9282a?pvs=21)  |  |
| --taxonrectangle-layout | Activate taxonrectangle-layout which taxonomy of each node will be displayed as rectangular blocks in aligned panel. | TaxonRectangle Layout (https://www.notion.so/TaxonRectangle-Layout-3716e09f6c704cbe80648b60ee5c5296?pvs=21)  |  |
| --taxoncollapse-layout | Activate taxoncollapse-layout which taxonomy of each node will be displayed as rectangular blocks in aligned panel. And nodes will be automatically collapsed. | TaxonCollapse Layout (https://www.notion.so/TaxonCollapse-Layout-2820bff6b0ad44a3a079d3af2ad69847?pvs=21)  |  |

Only tree which was conducted with taxonomic annotation from treeprofiler in previous annotate step can use the taxonomic visualization.

### **TaxonClade Layout**

`--taxonclade-layout` will assign different color to each taxa from each rank. Each rank will be a individual layout.

```bash
cd taxonomic/

# using pre-annotated example archaea tree
treeprofiler plot -t archaea_annotated.nw --taxonclade-layout
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2038.png)

### **TaxonRectangle Layout**

`--taxonrectangle-layout` shows taxonomic classification as rectangular block from root to leaf.

```bash
cd taxonomic/

# using pre-annotated example archaea tree
treeprofiler plot -t archaea_annotated.nw --taxonrectangle-layout
```

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2039.png)

### **TaxonCollapse Layout**

`--taxoncollapse-layout` is similar to `--taxonrectangle-layout`, but it only show commen ancestor on one column in aligned panel which is shown as corresponding taxa from the rank. Users can switch which layout of rank to be visualized in control panel, once layout of rank is activated, tree will be collapsed based on the according rank. It is more accurate than `--taxonrectangle-layout` because it also shown the representative taxa in corresponding rank

```bash
cd taxonomic/

# using pre-annotated example archaea tree
treeprofiler plot -t archaea_annotated.nw --taxoncollapse-layout
```

Collapse at Phylum

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2040.png)

Collapse at Order

![Untitled](TreeProfiler%20commands%20and%20related%20arguments%20naming%2092cb884c62244183a421ffb7f1ddcb90/Untitled%2041.png)

## **Customize color in layout with color config**

treeprofiler provides the option to cusomize the color on layouts:

| Argument | Description | Comments |
| --- | --- | --- |
| --color-config COLOR_CONFIG | Path to the file to find the color for each variable. [default: None] |  |
| -sep CONFIG_SEP, --config-sep CONFIG_SEP | Column separator of color table. [default: \t] |  |

# Custom query (can be used in both `annotate` and `plot`)

Conditional query in annotated tree: 

| Command Option | Subcommand Availability | Description | Comments |
| --- | --- | --- | --- |
| --pruned-by | annotate, plot | Prunes the annotated tree based on specific conditions, removing branches or clades that do not meet the criteria. |  |
| --rank-limit | annotate, plot | Enables pruning of a taxonomically annotated tree based on the rank of classification. |  |
| --collapsed-by | plot | Allows users to collapse tree branches based on custom conditions, mainly focusing on internal nodes. |  |
| --highlighted-by | plot | Enables users to highlight tree nodes that meet specific conditions. |  |

**Query Syntax**

**Basic Query**

All the conditional query shared the same syntax, a standard query consists the following

`"<left_value> <operator> <right_value>"`

|  | Left Value | Operator | Right Value |
| --- | --- | --- | --- |
| Description | This is the property of either a leaf node or an internal node within the tree. It could be any metadata feature linked to the node, such as its taxonomic classification, gene expression levels, or other biological markers. For example, name, sci_name, suppor. | This part of the query specifies the relationship between the left and right values. Operators include: =, !=, >, >=, <, <=, and contains. | This is the custom criterion against which the left value is compared. Depending on the nature of the left value, this could be a numerical figure, a string, or even a list of values. |

```
--pruned-by|collapsed-by|highlighted-by "<left_value> <operator> <right_value>"

```

Example

```bash
cd 03_query/

# Conditional pruning, prune leaf node whose name contain "FALPE"
treeprofiler plot \
--tree basic_example1_annotated.nw \
--input-type newick \
--pruned-by "name contains FALPE"
```

Left panel is tree before prune, right panel is result after prune

![https://github.com/dengzq1234/treeprofiler_gallery/raw/main/prune.png?raw=true](https://github.com/dengzq1234/treeprofiler_gallery/raw/main/prune.png?raw=true)

```
# Conditional highlight
# select tree node whose name contains `FALPE` character
treeprofiler plot \
--tree basic_example1_annotated.nw \
--input-type newick \
--highlighted-by "name contains FALPE"

```

![https://github.com/dengzq1234/treeprofiler_gallery/raw/main/highlighted.jpeg?raw=true](https://github.com/dengzq1234/treeprofiler_gallery/raw/main/highlighted.jpeg?raw=true)

```
# select tree node whose sample1 feature > 0.50, here we using ete format which can resume the datatype
treeprofiler plot \
--tree basic_example1_annotated.ete \
--input-type ete \
--highlighted-by "sample1 > 0.50" \
--heatmap-layout sample1

# if use tree in newick format, we need to attach the prop2type file which can resume the datatype
treeprofiler plot \
--tree basic_example1_annotated.nw \
--input-type newick \
--prop2type basic_example1_prop2type.txt \
--highlighted-by "sample1 > 0.50" \
--heatmap-layout sample1

```

![https://github.com/dengzq1234/treeprofiler_gallery/raw/main/highlighted_numeric.png?raw=true](https://github.com/dengzq1234/treeprofiler_gallery/raw/main/highlighted_numeric.png?raw=true)

**Query in internal nodes**

Query in internal nodes' properties is also available, in this case, `left_value` of query will be the internal node property, remember to add the proper suffixes such as `_avg`, `_max`,etc, for the numerical data or `_counter` for categorical and boolean data.

Example

```
# select tree internal node where sample1_avg feature < 0.50
treeprofiler plot \
--tree basic_example1_annotated.ete \
--heatmap-layout sample1 \
--collapsed-by "sample1_avg < 0.50"

```

Syntax for internal node counter data

![https://github.com/dengzq1234/treeprofiler_gallery/raw/main/collapsed_numeric.png?raw=true](https://github.com/dengzq1234/treeprofiler_gallery/raw/main/collapsed_numeric.png?raw=true)

```
# collapse tree internal nodes, where `high` relative counter > 0.35 in random_type_counter property
treeprofiler plot \
--tree basic_example1_annotated.ete \
--input-type ete \
--rectangle-layout random_type \
--collapsed-by "random_type_counter:high > 0.35" \
--column-width 70

```

![https://github.com/dengzq1234/treeprofiler_gallery/raw/main/collapsed_counter.png?raw=true](https://github.com/dengzq1234/treeprofiler_gallery/raw/main/collapsed_counter.png?raw=true)

**AND and OR conditions**

The syntax for the AND condition and OR condition in TreeProfiler is:

AND condition will be under one argument, syntax seperated by `,`, such as

```
# select tree  node where sample1 feature > 0.50 AND sample2 < 0.2
treeprofiler plot \
--tree basic_example1_annotated.ete \
--input-type ete \
--heatmap-layout sample1 sample2 sample3 sample4 sample5 \
--highlighted-by "sample1>0.50,sample2<0.2"

```

OR condition will be used more than one arguments

![https://github.com/dengzq1234/treeprofiler_gallery/raw/main/highlighted_and.png?raw=true](https://github.com/dengzq1234/treeprofiler_gallery/raw/main/highlighted_and.png?raw=true)

```
# select tree node where sample1 feature > 0.50 OR sample2 < 0.2
treeprofiler plot \
--tree basic_example1_annotated.ete \
--input-type ete \
--heatmap-layout sample1 sample2 sample3 sample4 sample5 \
--highlighted-by "sample1>0.50" \
--highlighted-by "sample2<0.2"

```

![https://github.com/dengzq1234/treeprofiler_gallery/raw/main/highlighted_or.png?raw=true](https://github.com/dengzq1234/treeprofiler_gallery/raw/main/highlighted_or.png?raw=true)

**conditional limit based on taxonomic level**

Prune taxonomic annotated tree based on following taxonomic rank level, `kingdom`, `phylum`, `class`, `order`, `family`, `genus`, `species`, `subspecies`

```
# Case in GTDB
# before pruning
treeprofiler plot \
--tree gtdb_example1_annotated.ete \
--taxonclade-layout

```

before rank limit

![https://github.com/dengzq1234/treeprofiler_gallery/raw/main/gtdb_taxa.png?raw=true](https://github.com/dengzq1234/treeprofiler_gallery/raw/main/gtdb_taxa.png?raw=true)

```
# prune tree in visualization, rank limit to family level
treeprofiler plot \
--tree gtdb_example1_annotated.ete \
--input-type ete \
--rank-limit class \
--taxonclade-layout

```

After rank-limit  As you see, class branches of target gtdb tree are all pruned and only left the internal branches which rank as class.

![https://github.com/dengzq1234/treeprofiler_gallery/raw/main/gtdb_taxa_rank_class.png?raw=true](https://github.com/dengzq1234/treeprofiler_gallery/raw/main/gtdb_taxa_rank_class.png?raw=true)